
package gtp_classes;




public class Mostrar_poco {
    
 public  void Mshow(String texto) throws InterruptedException{
   
    String ps;
    String ratio="";
            
    for (int i = 0; i < texto.length(); i++) {
            
          ps =  String.valueOf(texto.charAt(i));
           
          ratio = ratio + ps;
          
          proyectogpt.Interfaz.txt_A.setText(ratio);
          
        Thread.sleep(300);
        }
         
    }   

   
}
