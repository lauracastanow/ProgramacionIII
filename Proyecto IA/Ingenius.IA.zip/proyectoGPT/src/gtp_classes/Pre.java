
package gtp_classes;

public class Pre {
 
public String respuesta;

private String p1 ="¿Qué es Array?";
private String p2 ="¿Cómo se declara un arreglo unidimensional?";
private String p3 ="¿Cómo se asignan valores en un Array?";
private String p4 ="¿Cómo se accede a un elemento específico en un arreglo?";
private String p5 ="¿Qué son los arreglos multidimensionales?";
private String p6 ="¿Qué es el ordenamiento de arreglo?";
private String p7 ="¿Qué es una búsqueda lineal en arreglos?";
private String p8 ="¿Cómo se pasan los arreglos a los métodos?";
private String p9 ="¿Cómo se obtiene el tamaño del arreglo?";
private String p10 ="¿Cómo se crea una matriz?";
private String p11 ="¿Qué es SQL?";
private String p12 ="¿Cómo se realiza una conexión a una base de datos desde una aplicacion ?";
private String p13 ="¿Cómo se crea una tabla en una base de datos SQL?";
private String p14 ="¿¿Cómo se seleccionan datos de una tabla en SQL?";
private String p15 ="¿Cómo se manejan las transacciones en una base de datos SQL desde una aplicación?";
private String p16 ="¿Cuáles son algunas ventajas y desventajas de utilizar ORMs(Object-Relational Mapping) como Hibernate en Java y SQLAlchemy en Python?";
private String p17 ="¿Cómo se realiza la gestión de errores al ejecutar consultas SQL desde una aplicación?";
private String p18 ="¿Cómo se insertan nuevos registros en una tabla SQL desde un programa Python y desde un programa Java?";
private String p19 ="¿Cómo se manejan las excepciones relacionadas con bases de datos en programas?" ;
private String p20 ="¿Cómo se concatenan cadenas ?";
private String p21 ="¿Cómo se verifica si una cadena contiene otra cadena?";
private String p22 ="¿Cuál es la diferencia entre una cadena mutable e inmutable ?";
private String p23 ="¿Con qué método se divide una cadena en substrings?";
private String p24 ="¿Qué función se utiliza para convertir una cadena a mayúsculas?";
private String p25 ="¿Cómo se declara una cadena?";
private String p26 ="¿Cuál es el método para obtener la longitud (número de caracteres) de una cadena?";
private String p27 ="¿Cómo se puede obtener un carácter específico en una cadena?";
private String p28 ="28:¿Cómo se quitan los espacios en blanco al principio y al final de una cadena?";
private String p29 ="29:¿Cómo se compara el contenido de dos cadenas para verificar si son iguales?" ;
private String p30 ="¿Qué función se utiliza para formatear cadenas?";
private String p31 ="cuanto es 1+1";
private String p32 ="quien es el amor de richi";
        
public String responder(String pregunta){
    
if        (pregunta.equals(p1)) {
   respuesta = "Respuesta en Java: Se conoce como una estructura de datos donde se puede\n" +
"almacenar un conjunto o grupo de datos de un mismo tipo. Declarando su tamaño\n" +
"desde el inicio, este tamaño no puede ser cambiado mientras el programa se esté\n" +
"ejecutando.\n\n"
           + "Respuesta en Python: Es un tipo de variable donde se puede se almacenan u\n" +
"hospedan dentro de sí mismo valores al mismo tipo. Los datos no se alojan en el\n" +
"mismo lugar en un tiempo igual pero, sí presentan una serie de contenedores que\n" +
"forman el arreglo mientras los datos se van guardando en los contenedores. "; 
} else if (pregunta.equals(p2)) {
   respuesta = "Respuesta en Java: Se declara como “tipo[] nombreArreglo\n\n"
           + "Respuesta en Python:Se declara como “nombre_arreglo = []”."; 
} else if (pregunta.equals(p3)) {
 respuesta = "Respuesta en Java: Cuando se tiene declarado un arreglo, se le asigna un tamaño,\n" +
"puede accederse a los datos dentro del mismo arreglo y asignar los valores de cada\n" +
"elemento. Se hace de la siguiente manera:\n" +
"arreglo[indicador] = valor;\n\n"
         + "Respuesta en Python: Primero se define el arreglo que se va trabajar, se indica el\n" +
"índice del Array para poder acceder a un elemento específico. Para asignar el\n" +
"elemento es así:\n" +
"arreglo[0] = 5";
} else if (pregunta.equals(p4)) {
   respuesta = "Respuesta en Java: Usando el índice del elemento en Java, por ejemplo,\n" +
"“arreglo[indice]”.\n\n"
           +"Respuesta en Python: Para acceder al elemento en Python, por ejemplo,\n" +
"“arreglo[indice]”."; 
} else if (pregunta.equals(p5)) {
 respuesta = "Respuesta en Java: los arreglos multidimensionales en Java son una forma de\n" +
"organizar datos en múltiples dimensiones, lo que facilita la representación de\n" +
"estructuras de datos más complejas y tabulares en tus programas.\n\n"+
        "Respuesta en Python: Los arreglos multidimensionales en Python se llaman\n" +
"generalmente \"listas anidadas\" o \"listas de listas\". Estas estructuras de datos permiten\n" +
"almacenar datos en una forma bidimensional o incluso tridimensional y más allá.\n" +
"Aunque no hay una estructura de datos específica llamada \"arreglo multidimensional\"\n" +
"en Python, las listas anidadas pueden usarse para lograr el mismo propósito." ;
} else if (pregunta.equals(p6)) {
   respuesta = "Respuesta en Java: El ordenamiento de datos se utiliza para poner en un orden\n" +
"específico los datos, ya sea de forma ascendente o descendente. Los más conocidos\n" +
"son: Bubble sort, Insertion sort, Selection Sort, Merge sort y Quick sort.\n\n"
           + "Respuesta en Python: El ordenamiento en Python se hace por medio de un comando\n" +
"Sort, desde una librería Numpy. Por lo que se utilizan funciones nativas para\n" +
"modificar internamente el arreglo sin esperar el valor de retorno."; 
} else if (pregunta.equals(p7)) {
 respuesta = "Respuesta en Java: Consiste en recorrer la estructura de datos mientras se comparan\n" +
"los elementos uno a uno hasta encontrar el valor buscado, por lo que, si el valor que se\n" +
"busca está en el inicio el tiempo y el recorrido serán más cortos.\n\n"
         + "Respuesta en Python: Se compara uno a uno los elementos de la lista con el valor de\n" +
"“x” y se retorna el valor de la posición donde se encuentra. Por otro lado, si el valor\n" +
"en la posición de la lista se le hacen determinadas comparaciones y si el valor no se\n" +
"encuentra, se realizan varias comparaciones dependiendo de los elementos que\n" +
"presente el arreglo.";
} else if (pregunta.equals(p8)) {
   respuesta = "Respuesta en Java: Para pasar un arreglo como argumento a un método, se\n" +
"especifica el nombre del arreglo sin corchetes. Un ejemplo para indicar el arreglo, se\n" +
"declara como:\n" +
"int temperaturaPorHora[ ] = new int[24];\n" +
"La llamada al método es:\n" +
"modificarArreglo(temperaturaPorHora);\n\n"
           + "Respuesta en Python: Aunque en Python no presenta arreglos, tiene listas. Por lo\n" +
"que, puede convertir una lista de Python en un array de Numpy, donde la forma más\n" +
"simple es usar la función np.array() tomando una iteración para devolverla en un\n" +
"array de NumPy.\n" +
"import numpy as np\n" +
"lst = [0, 1, 100, 42, 13, 7]\n" +
"print(nop.array(lst))"; 
} else if (pregunta.equals(p9)) {
 respuesta = "Respuesta en Java: La variable length permite obtener el tamaño del arreglo, sirve\n" +
"también para los objetos null. Sirve para solo tener una lectura de los elementos.\n\n"
         + "Respuesta en Python: Para obtener la cantidad de elementos, se emplea la función\n" +
"len, pasada por la lista. Por lo que devolverá un número para indicar el tamaño."; 
} else if (pregunta.equals(p10)) {
   respuesta = "Respuesta en Java: Una matriz necesita dos índices para acceder a los elementos. De\n" +
"manera gráfica, se puede observar como una tabla con n filas y n columnas. Por\n" +
"ejemplo:\n" +
"int [ ][ ] ventas = new ventas[4][6];\n\n"
           + "Respuesta en Python: Se puede crear una matriz utilizando listas anidadas. Los datos\n" +
"son almacenados en filas y columnas. Son matrices rectangulares bidimensionales.\n" +
"Pueden haber datos como: números, cadenas, expresiones, símbolos. Un empleo sería:\n" +
"A = [[1, 4, 5], [-5, 8, 9]]\n" +
"print(“A =”, A)\n" +
"print(“A[1] =”, A[1])"; 
} else if (pregunta.equals(p11)) {
 respuesta = "Respuesta en Java: Para el lenguaje Java, SQL (Structured Query Language) es un\n" +
"lenguaje utilizado para gestionar bases de datos relacionales.\n\n"
         + "Respuesta en Python: Para el lenguaje de Python, SQL (Structured Query Language)\n" +
"es un lenguaje utilizado para gestionar bases de datos relacionales.";
} else if (pregunta.equals(p12)) {
   respuesta = "Respuesta en Java: En Java, puedes utilizar JDBC para establecer conexiones a\n" +
"bases de datos.\n\n"
           + "Respuesta en Python:En Python, puedes utilizar bibliotecas como SQLAlchemy o el\n" +
"módulo “sqlite3”."; 
} else if (pregunta.equals(p13)) {
 respuesta = "Respuesta en Java: En Java, se utiliza la sentencia SQL “CREATE TABLE”\n" +
"seguida de la definición de columnas y tipos de datos en un objeto “Statement” de\n" +
"JDBC.\n\n"
         + "Respuesta en Python: En Python, utilizando SQLAlchemy, puedes definir una tabla\n" +
"como una clase Python y luego crearla en la base de datos mediante la función\n" +
"“create_all()”."; 
} else if (pregunta.equals(p14)) {
   respuesta = "Respuesta en Java: En Java, se utiliza la sentencia SQL “SELECT” seguida de los\n" +
"nombres de las columnas o “*” para seleccionar todas las columnas mediante un\n" +
"objeto “Statement” de JDBC.\n\n"
           + "Respuesta en Python: En Python, utilizando SQLAlchemy, puedes crear una\n" +
"consulta SQL y ejecutarla para seleccionar datos de una tabla."; 
} else if (pregunta.equals(p15)) {
 respuesta = "Respuesta en Java: En Java, puedes usar las clases de JDBC, como “Connection”,\n" +
"“Statement”, y “PreparedStatement”, para administrar transacciones. Puedes\n" +
"iniciar una transacción con “setAutoCommit(false)”, realizar operaciones en la\n" +
"transacción y luego confirmar o revertir la transacción según sea necesario.\n\n" +
             "Respuesta en Python:En Python, utilizando SQLAlchemy, puedes iniciar una\n" +
"transacción utilizando “begin()” en un objeto de sesión. Luego, puedes realizar\n" +
"operaciones en la transacción y confirmar o revertir la transacción utilizando\n" +
"“commit()” o “rollback()” según sea necesario.";
} else if (pregunta.equals(p16)) {
   respuesta = "Respuesta en Java: Hibernate es una biblioteca de mapeo objeto-relacional (ORM)\n" +
"en Java que simplifica la interacción con bases de datos relacionales. Ventajas\n" +
"incluyen la abstracción de la capa de base de datos y la portabilidad del código entre\n" +
"\n" +
"diferentes bases de datos. Sin embargo, puede introducir cierta complejidad y\n" +
"sobrecarga en proyectos más pequeños.\n\n "
           + "Respuesta en Python:SQLAlchemy es una biblioteca de mapeo objeto-relacional\n" +
"(ORM) en Python que proporciona una forma eficiente y flexible de interactuar con\n" +
"bases de datos. Ventajas incluyen un alto nivel de control sobre las consultas SQL\n" +
"generadas y la capacidad de trabajar con bases de datos tanto relacionales como no\n" +
"relacionales. Al igual que Hibernate, puede aumentar la complejidad en proyectos\n" +
"más pequeños."; 
} else if (pregunta.equals(p17)) {
 respuesta = "Respuesta en Java: En Java, puedes utilizar bloques “try-catch” para capturar\n" +
"excepciones generadas durante la ejecución de consultas SQL. Excepciones comunes\n" +
"incluyen “SQLException” para errores de base de datos.\n\n"
          + "Respuesta en Python: En Python, puedes utilizar bloques “try-except” para\n" +
"capturar excepciones generadas durante la ejecución de consultas SQL. Excepciones\n" +
"comunes incluyen “SQLAlchemyError” para errores de SQLAlchemy.";
} else if (pregunta.equals(p18)) {
   respuesta = "Respuesta en Java:En Java, se utilizan objetos “PreparedStatement” o\n" +
"“Statement” de JDBC para ejecutar consultas de inserción.\n\n"
           + "Respuesta en Python: En Python, puedes utilizar SQL o bibliotecas como\n" +
"SQLAlchemy para ejecutar instrucciones SQL INSERT."; 
} else if (pregunta.equals(p19)) {
 respuesta = "Respuesta en Java:En Java, se utilizan bloques “try-catch” para capturar\n" +
"excepciones de JDBC, como “SQLException.”\n\n"
           + "Respuesta en Python:En Python, puedes utilizar bloques “try-except” para capturar\n" +
"excepciones, como “sqlite3.Error” o “sqlalchemy.exc.SQLAlchemyError.”";
} else if (pregunta.equals(p20)) {
   respuesta = "Respuesta en Java: Se utiliza el operador “+” o “concat()”.\n\n" +
               "Respuesta en Python: Se utiliza el operador “+” o “str.join()”.\n"; 
} else if (pregunta.equals(p21)) {
 respuesta = "Respuesta en Java: Usando el método “contains()” o “indexOf()”.\n\n"
           + "Respuesta en Python: Usando “in” o “str.find()”.";
} else if (pregunta.equals(p22)) {
   respuesta = "Respuesta en Java: En Java, las cadenas se implementan como objetos de la clase\n" +
"“String”, que son inmutables. Sin embargo, también existe una clase llamada\n" +
"“StringBuilder” que se utiliza para crear cadenas mutables. Puedes modificar su\n" +
"contenido sin crear un nuevo objeto cada vez.\n\n"
           + "Respuesta en Python: En Python, las cadenas son objetos inmutables, lo que\n" +
"significa que no se pueden modificar una vez que se crean. Cualquier operación que\n" +
"parezca modificar una cadena en realidad crea una nueva cadena en memoria. Por\n" +
"ejemplo, al concatenar dos cadenas, se crea una tercera cadena con el resultado.";
} else if (pregunta.equals(p23)) {
 respuesta = "Respuesta en Java:Utilizando el método “split()”.\n\n"
           + "Respuesta en Python:Utilizando “split()” o “str.split()”.";
} else if (pregunta.equals(p24)) {
   respuesta = "Respuesta en Java: Se utiliza la función “toUpperCase()”.\n\n"
           + "Respuesta en Python: Se utiliza la función “upper()”."; 
} else if (pregunta.equals(p25)) {
 respuesta = "Respuesta en Java:En Java, se declara como “String cadena = \"Texto\"”.\n\n"
           + "Respuesta en Python: En Python, se declara como “cadena = \"Texto\"”.";
} else if (pregunta.equals(p26)) {
   respuesta = "Respuesta en Java: En Java, puedes usar “cadena.length()”.\n\n"
           + "Respuesta en Python:En Python, puedes usar “len(cadena)”."; 
} else if (pregunta.equals(p27)) {
 respuesta = "Respuesta en Java:En Java, puedes usar “charAt(CARACTER A BUSCAR).”\n\n"
           + "Respuesta en Python:En Python, puedes usar la indexación, “cadena[CARACTER\n" +
"A BUSCAR]”.";
} else if (pregunta.equals(p28)) {
 respuesta = "Respuesta en Java: En Java, puedes usar “trim()”.\n\n"
           + "Respuesta en Python: En Python, puedes usar “strip()”."; 
 } else if (pregunta.equals(p29)) {
 respuesta = "Respuesta en Java: En Java, debes usar el método “equals()”.\n\n"
           + "Respuesta en Python: En Python, puedes usar el operador “==”";
 } else if (pregunta.equals(p30)) {
 respuesta = "Respuesta en Java: En Java, puedes usar “String.format()” o concatenación con el\n" +
"operador “+”.\n\n"
           + "Respuesta en Python:En Python, puedes usar “str.format()”";
 } else if (pregunta.equals(p31)) {
 respuesta = "es obviamente 2, para esto estudia ingenieria??";
 } else if (pregunta.equals(p32)) {
 respuesta = "es jose diaz amariles";
} else {

 respuesta = "Verifica Tu Pregunta, No La Entiendo";
}

return respuesta;
}
    
    
    
    
    
    
    
}
